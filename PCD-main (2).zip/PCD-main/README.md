# PCD

Projet de development et conception
made with react-native expo
//create an expo project
expo init name-of-project

To test this app on your phone or on emulator/simulator
you must install node, expo

//install expo-cli globally
sudo npm install -g expo-cli

//install the dependencies
npm i

//run metro bundler
npm start
