export default {
  primary: "#87CEEB",
  secondary: "#F08080",
  white: "#FFFFFF",
  black: "#000000",
  medium: "#6E6969",
  light: "#F8F4F4",
  dark: "#0C0C0C",
  danger: "#FF5252",
};
